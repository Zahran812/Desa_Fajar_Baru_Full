<div style="text-align: center; margin-bottom: 20px;">
    <img src="{{ asset('kop/kabupaten.png') }}" style="width: 100px; margin-bottom: 10px;" alt="Logo">

    <h2 style="margin:0; font-size: 20px;">KECAMATAN JATI AGUNG</h2>
    <h3 style="margin:0; font-size: 18px;">DESA FAJAR BARU</h3>
    <p style="margin:0; font-size: 14px;">
        JL. RA. BASYID No. 1 FAJAR BARU 35564
    </p>
</div>

<hr style="border: 1px solid black; margin-top: 10px; margin-bottom: 10px;">
